public class Pessoa{
    public String name;
    public int idade;
    public int voto;
    public String titulo;
    public boolean candidato;
  
    public Pessoa(String name, int idade,int voto, String titulo, boolean candidato){
        this.name   =    name;
        this.idade  =    idade;
        this.voto   =    voto;
        this.titulo   =  titulo;
        this.candidato = candidato;
    }
    
}
