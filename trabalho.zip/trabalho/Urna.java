public class Urna{
    public static void main(String[] args) {
        
        Candidato candidato1 = new Candidato("Arthur",51,"Patriota");
        Candidato candidato2 = new Candidato("Boulos",50,"PSOL");
        
        Pessoa pessoa1 = new Pessoa("Guilherme Lucio da Silva", 20,51,"443992540116", false);
        
        if(direito.TemDireito(pessoa1)==true){
            System.out.println(pessoa1.name + " TEM DIREITO AO VOTO ");
        }
        else{
            System.out.println(pessoa1.name + " NÃO TEM DIREITO AO VOTO");
        }
        
        if(Pessoa.voto(pessoa1)=51){
            Voto51();
        }
        if(Pessoa.Voto(pessoa1)=50){
            Voto50();
        }
        else{
            Branco();
        }
    }
}
