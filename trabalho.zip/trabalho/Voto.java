public class Voto{

    public int voto51=0;
    public int voto50=0;
    public int votobranco=0;
  
    public Voto(int votoa, int votob, int votobranco){
        this.voto51 = voto51;
        this.voto50 = voto50;
        this.votobranco = votobranco;
    }
    public boolean TemDireito(Pessoa pessoa1){
        if(pessoa1.candidato==true){
            return true;
        }
        else{
            return false;
        }
    }
    public void Voto51(){
        voto51 = voto51+1;
    }
    public void Voto50(){
        voto50 = voto50+1;
    }
    public void Branco(){
        votobranco = votobranco+1;
    }

}