public class Candidato{
    public String name;
    public int numero;
    public String partido;
    
    
    public Candidato(String name, int numero, String partido){
        this.name = name;
        this.numero = numero;
        this.partido = partido;
    }
    
}
